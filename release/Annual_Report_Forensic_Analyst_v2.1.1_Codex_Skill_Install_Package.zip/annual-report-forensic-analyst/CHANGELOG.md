# Changelog

## v2.1.1

Fixed:
- Added required SKILL.md YAML metadata header
- Added valid Codex skill registration fields
- Separated Codex installation package from GitHub documentation package
