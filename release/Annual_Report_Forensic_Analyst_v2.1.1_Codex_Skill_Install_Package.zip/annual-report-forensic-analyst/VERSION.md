# Version

Annual Report Forensic Analyst

Version: v2.1.1

Type:
Codex Skill Install Package

Change:
Packaging compatibility release.

Fixed:
- Added YAML front matter metadata
- Added Codex skill name
- Added Codex skill description
- Improved skill registration compatibility
