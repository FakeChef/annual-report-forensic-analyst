# Annual Report Forensic Analyst v2.1.1

Codex skill package for forensic annual report analysis.

Install location:

.codex/skills/annual-report-forensic-analyst/

After installation restart Codex and verify the skill appears in `$` autocomplete.

Core capabilities:
- Single-Year Forensic Mode
- Multi-Year Forensic Mode
- Executive Slide Mode

The skill focuses on evidence-based annual report analysis.
